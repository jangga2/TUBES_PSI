/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.id.ac.unpas.psi.tubes.controller;
import com.mysql.jdbc.Statement;
import com.id.ac.unpas.psi.tubes.model.data.BarangKeluarModel;
import com.id.ac.unpas.psi.tubes.model.pojo.BarangKeluar;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
/**
 *
 * @author Egy
 */
public class BarangKeluarController {
     public List<BarangKeluar> loadBarangKeluar() throws SQLException {
        BarangKeluarModel model = new BarangKeluarModel();
        return model.loadBarangKeluar();
    }
     
       public int tambah(BarangKeluar barang) throws SQLException {
        BarangKeluarModel model = new BarangKeluarModel();
        return model.tambah(barang);
        
    }
       
        public int update(BarangKeluar barang) throws SQLException{
        BarangKeluarModel model = new BarangKeluarModel();
        return model.update(barang);
    }
    
        public int delete(BarangKeluar barang) throws SQLException {
        BarangKeluarModel model = new BarangKeluarModel();
        return model.delete(barang);
    }
}
