/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.id.ac.unpas.psi.tubes.model.data;
import com.id.ac.unpas.psi.tubes.view.BarangKeluarFrame;
import com.id.ac.unpas.psi.tubes.model.pojo.BarangKeluar;
import com.id.ac.unpas.psi.tubes.utilities.DatabaseUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Egy
 */
public class BarangKeluarModel {
    
      public List<BarangKeluar> loadBarangKeluar() throws SQLException {
        List<BarangKeluar> brgList;
        Connection con = DatabaseUtilities.getConnection();
        
        try {
            Statement state = con.createStatement();
            ResultSet rs = state.executeQuery("SELECT * FROM barangKeluar");
            brgList = new ArrayList<>();
                while (rs.next()){
                    BarangKeluar brg = new BarangKeluar();
                    brg.setIdBarang(rs.getString("id_brg"));
                    brg.setNama(rs.getString("nama_barang"));
                    brg.setHarga(rs.getInt("harga_barang"));
              
                    brg.setTglKeluar(rs.getString("tgl_keluar"));
                    brg.setStok(rs.getInt("stok"));
                    brgList.add(brg);
                }
            
        } finally {
            if (con != null) {
                con.close();
            }
        }
    return brgList;
    }
      
        public int tambah(BarangKeluar brg) throws SQLException {
        Connection con = DatabaseUtilities.getConnection();
        
        try {
            PreparedStatement stat = con.prepareStatement("INSERT INTO barangKeluar values(?,?,?,?,?)");
            stat.setString(1, brg.getIdBarang());
            stat.setString(2, brg.getNama());
            stat.setInt(3, brg.getHarga());
           
            stat.setString(4, brg.getTglKeluar());
            stat.setInt(5, brg.getStok());
            return stat.executeUpdate();
        } finally {
            
            if (con != null) {
                con.close();
            }
        }
    }
        
         public int update(BarangKeluar brg) throws SQLException {
       Connection con = DatabaseUtilities.getConnection();
        try {
            PreparedStatement stat = con.prepareStatement("UPDATE barangKeluar SET nama_barang=?, harga_barang=?, stok=?  WHERE id_brg=?");
            stat.setString(1, brg.getNama());
            stat.setInt(2, brg.getHarga());
            stat.setInt(3, brg.getStok());
            stat.setString(4, brg.getIdBarang());
            return stat.executeUpdate();
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }
         
             public int delete(BarangKeluar brg) throws SQLException {
         Connection con = DatabaseUtilities.getConnection();
        try {
            PreparedStatement stat = con.prepareStatement("DELETE FROM barangKeluar WHERE id_brg=?");
            stat.setString(1, brg.getIdBarang());
            return stat.executeUpdate();
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }
}
